export const LINKS = {
  github: "https://github.com/heyravinder",
  linkedin: "https://www.linkedin.com/in/ravinder-singh-a32485448/",
  email: "mailto:onlyrvi@gmail.com",
};
export const EMAIL = "onlyrvi@gmail.com";
/* For a working form on your own hosting, paste a Formspree or Web3Forms URL here. Empty = opens the visitor's email app. */
export const FORM_ENDPOINT = "";
export const MOD = /Mac/.test(navigator.platform) ? "⌘" : "Ctrl";
export const reduceMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
export const go = (id) => { if (id === "top") window.scrollTo({ top: 0, behavior: "smooth" }); else document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); };

/* Edit these lists to update the portfolio. */
export const PROJECTS = [
  { name: "ShopSphere", type: "Web", icon: "🛍️", grad: "linear-gradient(135deg,#6a4cff,#b69cff)", tags: ["React", "Vite", "Tailwind CSS", "Context API"],
    desc: "A modern e-commerce store with product browsing, filters, cart and checkout, built as a full React application.",
    repo: "https://github.com/heyravinder/shopsphere-ecommerce-shop" },
  { name: "TaskFlow", type: "Web", icon: "✅", grad: "linear-gradient(135deg,#1fbf93,#8ae8cb)", tags: ["JavaScript", "Dashboard", "Productivity"],
    desc: "A productivity dashboard for planning and tracking daily tasks in one clean, organised view.",
    repo: "https://github.com/heyravinder/taskflow-productivity-dashboard" },
  { name: "SkyCast", type: "Web", icon: "⛅", grad: "linear-gradient(135deg,#ff5d8f,#ffb3a0)", tags: ["JavaScript", "Weather API", "Responsive"],
    desc: "A live weather app that shows current conditions and forecasts for any city you search.",
    repo: "https://github.com/heyravinder/skycast-live-weather-app" },
  { name: "Student Management System", type: "Python", icon: "🎓", grad: "linear-gradient(135deg,#ffc53d,#ffe6a0)", tags: ["Python", "SQLite", "Desktop"],
    desc: "A desktop application for managing student records, with create, update, delete and search functions backed by SQLite." },
  { name: "Personal Portfolio Website", type: "Web", icon: "🌐", grad: "linear-gradient(135deg,#3b82f6,#9cc4ff)", tags: ["HTML", "CSS", "JavaScript"],
    desc: "A responsive website presenting my background and technical work." },
];
export const BARS = [["Python", 75], ["HTML & CSS", 80], ["React", 65], ["JavaScript", 55], ["C", 60], ["SQL & SQLite", 55], ["Git & GitHub", 50]];
export const LEARN = [["⚛️", "React in depth", "Router, Context API and state patterns"], ["🗄️", "Supabase", "Auth and a real database for my projects"], ["🎨", "Tailwind CSS", "Faster, more consistent styling"], ["🧠", "Data structures & algorithms", "Sharper problem solving"]];
export const BUILD = [["🚀", "Landing pages", "Fast, focused pages that turn visitors into leads."], ["📱", "Responsive websites", "Layouts that look right on phones, tablets and desktops."], ["📊", "Dashboards", "Clean data views like task trackers and admin panels."], ["🛒", "E-commerce front ends", "Product lists, filters, carts and checkout flows."], ["🌦️", "API-powered apps", "Apps that fetch and show live data, like weather."], ["🗃️", "Python desktop tools", "Record-keeping apps backed by SQLite."]];
export const FLOW = [["01", "Plan", "Break the idea into small phases and a clear feature list."], ["02", "Design", "Sketch mobile-first layouts and reusable components."], ["03", "Code", "Build in React and commit to Git in small steps."], ["04", "Test", "Check every screen size and fix what breaks."], ["05", "Deploy", "Ship it online with Vercel and keep improving."]];
export const NOTES = [
  ["Context API without the headache", "When several components need the same data, like a shopping cart, I lift it into a Context provider. One provider per concern (cart, theme, auth) and a small custom hook such as useCart keeps components clean."],
  ["Start with the data model", "In my Student Management System I defined the table and the four operations (create, read, update, delete) before touching the interface. Once the data layer is solid, the UI is just buttons that call it."],
  ["Responsive by default", "I design for the phone first, then add room for bigger screens. CSS grid with auto-fit lets cards reflow on their own without a pile of media queries."],
];
export const NAV = [["about", "About"], ["projects", "Projects"], ["skills", "Skills"], ["build", "Build"], ["notes", "Notes"], ["contact", "Contact"]];
export const MARQUEE = ["React", "Python", "JavaScript", "SQL", "Tailwind CSS", "Responsive design", "Git", "C", "SQLite", "Problem solving"];

export const Icon = ({ d }) => (<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d={d} /></svg>);
export const GH = "M12 .5a11.5 11.5 0 0 0-3.64 22.41c.58.1.79-.25.79-.56v-2c-3.2.7-3.88-1.37-3.88-1.37-.52-1.33-1.28-1.69-1.28-1.69-1.05-.71.08-.7.08-.7 1.15.08 1.76 1.19 1.76 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11 11 0 0 1 5.78 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.84 1.19 3.1 0 4.42-2.7 5.4-5.27 5.68.41.36.78 1.06.78 2.14v3.17c0 .31.21.67.8.56A11.5 11.5 0 0 0 12 .5z";
export const LI = "M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z";
export const MAIL = "M2 5h20v14H2zM3.5 6.5l8.5 6.5 8.5-6.5";

