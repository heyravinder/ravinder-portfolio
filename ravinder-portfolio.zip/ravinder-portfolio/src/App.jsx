import { useState, useEffect, useRef } from "react";
import { LINKS, EMAIL, FORM_ENDPOINT, MOD, reduceMotion, go, PROJECTS, BARS, LEARN, BUILD, FLOW, NOTES, NAV, MARQUEE, Icon, GH, LI, MAIL } from "./data";

function Loader() {
  const [s, setS] = useState(0);
  useEffect(() => { const a = setTimeout(() => setS(1), 1100), b = setTimeout(() => setS(2), 1950); return () => { clearTimeout(a); clearTimeout(b); }; }, []);
  if (s === 2) return null;
  return <div className={"loader" + (s ? " out" : "")}><span className="logo">RS</span></div>;
}

function Cursor() {
  const dot = useRef(null), ring = useRef(null);
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    document.documentElement.classList.add("has-cursor");
    let x = -100, y = -100, rx = -100, ry = -100, raf = 0;
    const mv = (e) => { x = e.clientX; y = e.clientY; dot.current.style.transform = `translate(${x}px,${y}px)`; ring.current.classList.toggle("big", !!(e.target.closest && e.target.closest("a,button,input,textarea,summary,.ball,.play,.card"))); };
    const loop = () => { rx += (x - rx) * 0.18; ry += (y - ry) * 0.18; ring.current.style.transform = `translate(${rx}px,${ry}px)`; raf = requestAnimationFrame(loop); };
    window.addEventListener("pointermove", mv); loop();
    return () => { window.removeEventListener("pointermove", mv); cancelAnimationFrame(raf); document.documentElement.classList.remove("has-cursor"); };
  }, []);
  return <><div className="cur-dot" ref={dot} /><div className="cur-ring" ref={ring} /></>;
}

function Particles() {
  const cv = useRef(null);
  useEffect(() => {
    const c = cv.current, ctx = c.getContext("2d"), dpr = Math.min(2, window.devicePixelRatio || 1);
    let w, h, ps, raf = 0, mx = -999, my = -999;
    const init = () => {
      w = window.innerWidth; h = window.innerHeight; c.width = w * dpr; c.height = h * dpr; c.style.width = w + "px"; c.style.height = h + "px"; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ps = Array.from({ length: Math.min(80, Math.round(w * h / 18000)) }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4, r: Math.random() * 2 + 1, c: Math.random() < 0.3 ? "255,93,143" : "120,92,255" }));
    };
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (const p of ps) {
        p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1;
        const dx = p.x - mx, dy = p.y - my, d = Math.hypot(dx, dy); if (d < 120 && d > 0) { p.x += dx / d * 1.2; p.y += dy / d * 1.2; }
        ctx.fillStyle = `rgba(${p.c},.7)`; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
        const a = ps[i], b = ps[j], d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 120) { ctx.strokeStyle = `rgba(120,92,255,${0.25 * (1 - d / 120)})`; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
    };
    const loop = () => { draw(); raf = requestAnimationFrame(loop); };
    const mv = (e) => { mx = e.clientX; my = e.clientY; };
    init(); if (reduceMotion()) draw(); else loop();
    window.addEventListener("resize", init); window.addEventListener("pointermove", mv);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", init); window.removeEventListener("pointermove", mv); };
  }, []);
  return <canvas className="parts" ref={cv} aria-hidden="true" />;
}

function useTyping(words) {
  const [t, setT] = useState("");
  useEffect(() => {
    if (reduceMotion()) { setT(words[0]); return; }
    let i = 0, j = 0, del = false, id;
    const tick = () => {
      const w = words[i]; j += del ? -1 : 1; setT(w.slice(0, j));
      let d = del ? 45 : 85;
      if (!del && j === w.length) { del = true; d = 1400; } else if (del && j === 0) { del = false; i = (i + 1) % words.length; d = 350; }
      id = setTimeout(tick, d);
    };
    id = setTimeout(tick, 600);
    return () => clearTimeout(id);
  }, []);
  return t;
}

function useIST() {
  const [t, setT] = useState("");
  useEffect(() => {
    const f = () => setT(new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" }));
    f(); const id = setInterval(f, 30000); return () => clearInterval(id);
  }, []);
  return t;
}

function Reveal({ children, className = "", delay = 0 }) {
  const r = useRef(null);
  useEffect(() => {
    const el = r.current;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.classList.add("in"); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el); return () => io.disconnect();
  }, []);
  return <div ref={r} className={"rv " + className} style={{ transitionDelay: delay + "ms" }}>{children}</div>;
}

function Mascot() {
  const box = useRef(null), head = useRef(null), pupils = useRef(null);
  useEffect(() => {
    if (reduceMotion()) return;
    const move = (e) => {
      const r = box.current.getBoundingClientRect();
      const nx = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width * 0.5)) / 420));
      const ny = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height * 0.45)) / 420));
      head.current.style.transform = `translate(${nx * 16}px, ${ny * 9}px) rotate(${nx * 11}deg)`;
      pupils.current.style.transform = `translate(${nx * 8}px, ${ny * 7}px)`;
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);
  const [say, setSay] = useState("Hey, I’m Ravinder! 👋");
  useEffect(() => {
    const spots = [["top", "Hey, I’m Ravinder! 👋"], ["about", "Nice to meet you!"], ["projects", "Take a peek at my work 👀"], ["skills", "Go on, click a ball! 🎯"], ["build", "Need something built? 🛠️"], ["notes", "Little things I’ve learned 📚"], ["contact", "Say hi, I don’t bite 😄"]];
    const onScroll = () => {
      const y = window.scrollY + window.innerHeight * 0.4;
      let cur = spots[0][1];
      for (const [id, t] of spots) { const sec = document.getElementById(id); if (sec && sec.getBoundingClientRect().top + window.scrollY <= y) cur = t; }
      setSay(cur);
      box.current.style.opacity = window.scrollY < 300 ? 1 : 0.8;
    };
    onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="stage" ref={box} aria-hidden="true">
      <div className="bubble">{say}</div>
      <svg viewBox="0 0 400 480">
        <circle cx="70" cy="150" r="58" fill="#ff5d8f" opacity=".9" />
        <circle cx="338" cy="96" r="36" fill="#ffc53d" />
        <rect x="318" y="240" width="52" height="52" rx="14" fill="#1fbf93" transform="rotate(18 344 266)" />
        <path d="M44 480C44 384 114 340 200 340s156 44 156 140z" fill="#6a4cff" />
        <path d="M148 344c10 32 94 32 104 0" fill="#4b32c9" />
        <path d="M176 352v40M224 352v40" stroke="#ffc53d" strokeWidth="5" strokeLinecap="round" />
        <text x="200" y="448" textAnchor="middle" fontSize="34" fontWeight="800" fill="#ffc53d" fontFamily="sans-serif">RS</text>
        <rect x="178" y="292" width="44" height="60" rx="16" fill="#d99468" />
        <path d="M126 352c0 54 148 54 148 0" stroke="#1c1433" strokeWidth="9" fill="none" strokeLinecap="round" />
        <rect x="114" y="336" width="26" height="40" rx="12" fill="#ffc53d" />
        <rect x="260" y="336" width="26" height="40" rx="12" fill="#ffc53d" />
        <g ref={head} id="head" style={{ transformOrigin: "200px 330px" }}>
          <circle cx="116" cy="222" r="20" fill="#e8a982" />
          <circle cx="284" cy="222" r="20" fill="#e8a982" />
          <ellipse cx="200" cy="212" rx="88" ry="92" fill="#f0b48c" />
          <path d="M110 208L100 152L126 138L122 96L156 114L172 76L202 106L234 78L248 112L284 98L280 142L302 160L290 208C272 168 240 150 200 150C160 150 128 170 110 208Z" fill="#1c1433" />
          <path d="M146 186q18-12 36 0M218 186q18-12 36 0" stroke="#1c1433" strokeWidth="6" fill="none" strokeLinecap="round" />
          <ellipse cx="164" cy="218" rx="20" ry="22" fill="#fff" />
          <ellipse cx="236" cy="218" rx="20" ry="22" fill="#fff" />
          <g ref={pupils} id="pupils">
            <circle cx="164" cy="220" r="11" fill="#1c1433" /><circle cx="160" cy="214" r="4" fill="#fff" />
            <circle cx="236" cy="220" r="11" fill="#1c1433" /><circle cx="232" cy="214" r="4" fill="#fff" />
          </g>
          <path d="M200 230q-8 18 2 24" stroke="#c98760" strokeWidth="4" fill="none" strokeLinecap="round" />
          <circle cx="136" cy="258" r="14" fill="#ff5d8f" opacity=".35" /><circle cx="264" cy="258" r="14" fill="#ff5d8f" opacity=".35" />
          <g fill="#c98760"><circle cx="146" cy="246" r="2.4" /><circle cx="158" cy="252" r="2.4" /><circle cx="150" cy="260" r="2.4" /><circle cx="254" cy="246" r="2.4" /><circle cx="242" cy="252" r="2.4" /><circle cx="250" cy="260" r="2.4" /></g>
          <path d="M166 266q34 40 68 0z" fill="#fff" stroke="#1c1433" strokeWidth="5" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

const BALLS = ["Python", "C", "JavaScript", "React", "HTML", "CSS", "SQL", "SQLite", "Git", "GitHub", "Tailwind", "Vite", "OOP", "DSA"];
const PAL = [["#6a4cff", "#a08cff"], ["#ff5d8f", "#ff9bb9"], ["#ff9f1c", "#ffd166"], ["#1fbf93", "#6ee7c0"], ["#3b82f6", "#8bb8ff"], ["#ff6b4a", "#ffa98f"]];
const radius = (l) => Math.min(58, Math.max(36, 20 + l.length * 4.4));

/* Gravity playground: tap a ball to launch it, tap empty space to blast them all. */
function Playground() {
  const box = useRef(null), els = useRef([]);
  useEffect(() => {
    const el = box.current, reduce = reduceMotion();
    const bs = BALLS.map((l, i) => ({ r: radius(l), x: 80 + (i * 97) % Math.max(200, el.clientWidth - 160), y: -radius(l) - i * 70, vx: (Math.random() - 0.5) * 4, vy: 0 }));
    let raf = 0, on = false;
    const step = () => {
      const w = el.clientWidth, h = el.clientHeight;
      for (const b of bs) {
        b.vy += 0.5; b.vx *= 0.995; b.x += b.vx; b.y += b.vy;
        if (b.x < b.r) { b.x = b.r; b.vx *= -0.7; }
        if (b.x > w - b.r) { b.x = w - b.r; b.vx *= -0.7; }
        if (b.y > h - b.r) { b.y = h - b.r; b.vy *= -0.62; b.vx *= 0.97; if (Math.abs(b.vy) < 1.2) b.vy = 0; }
      }
      for (let i = 0; i < bs.length; i++) for (let j = i + 1; j < bs.length; j++) {
        const a = bs[i], c = bs[j]; let dx = c.x - a.x, dy = c.y - a.y;
        const d = Math.hypot(dx, dy) || 0.01, min = a.r + c.r;
        if (d < min) {
          dx /= d; dy /= d; const o = (min - d) / 2;
          a.x -= dx * o; a.y -= dy * o; c.x += dx * o; c.y += dy * o;
          const rv = (c.vx - a.vx) * dx + (c.vy - a.vy) * dy;
          if (rv < 0) { const k = rv * 0.85; a.vx += k * dx; a.vy += k * dy; c.vx -= k * dx; c.vy -= k * dy; }
        }
      }
      bs.forEach((b, i) => { els.current[i].style.transform = `translate(${b.x - b.r}px, ${b.y - b.r}px)`; });
    };
    const loop = () => { step(); raf = requestAnimationFrame(loop); };
    const burst = () => { let n = 0; const f = () => { step(); if (++n < 240) raf = requestAnimationFrame(f); }; f(); };
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !on) { on = true; if (reduce) { for (let i = 0; i < 500; i++) step(); } else loop(); }
      else if (!e.isIntersecting && on && !reduce) { on = false; cancelAnimationFrame(raf); }
    }, { threshold: 0.15 });
    io.observe(el);
    const down = (e) => {
      const rc = el.getBoundingClientRect(), px = e.clientX - rc.left, py = e.clientY - rc.top;
      const hit = bs.find((b) => Math.hypot(b.x - px, b.y - py) <= b.r);
      if (hit) { hit.vy = -(15 + Math.random() * 7); hit.vx += (Math.random() - 0.5) * 12; }
      else bs.forEach((b) => { const dx = b.x - px, dy = b.y - py, d = Math.hypot(dx, dy) || 1, f = Math.max(0, 1 - d / 320) * 22 + 4; b.vx += (dx / d) * f; b.vy += (dy / d) * f - 6; });
      if (reduce) { cancelAnimationFrame(raf); burst(); }
    };
    el.addEventListener("pointerdown", down);
    return () => { io.disconnect(); cancelAnimationFrame(raf); el.removeEventListener("pointerdown", down); };
  }, []);
  return (
    <div className="play glass" ref={box} role="group" aria-label={"Skills: " + BALLS.join(", ") + ". Tap the balls to make them bounce."}>
      {BALLS.map((l, i) => {
        const r = radius(l), [a, b] = PAL[i % PAL.length];
        return <div key={l} className="ball" ref={(n) => (els.current[i] = n)} style={{ width: r * 2, height: r * 2, fontSize: Math.max(11, Math.min(16, r * 0.3)) + "px", background: `radial-gradient(circle at 35% 30%, ${b}, ${a} 70%)`, transform: "translate(-300px,-300px)" }}>{l}</div>;
      })}
    </div>
  );
}

function Tilt({ p }) {
  const r = useRef(null);
  const mv = (e) => {
    if (reduceMotion()) return;
    const b = r.current.getBoundingClientRect(), x = (e.clientX - b.left) / b.width, y = (e.clientY - b.top) / b.height;
    r.current.style.transform = `perspective(900px) rotateY(${(x - 0.5) * 16}deg) rotateX(${(0.5 - y) * 14}deg) translateY(-6px)`;
    r.current.style.setProperty("--gx", x * 100 + "%"); r.current.style.setProperty("--gy", y * 100 + "%");
  };
  return (
    <article className="card glass" ref={r} onMouseMove={mv} onMouseLeave={() => { r.current.style.transform = ""; }}>
      <div className="banner" style={{ background: p.grad }} aria-hidden="true"><span className="emo">{p.icon}</span></div>
      <div className="body">
        <h3>{p.name}</h3><p>{p.desc}</p>
        <div className="tags">{p.tags.map((t) => <span className="tag" key={t}>{t}</span>)}</div>
        {p.repo && <div><a className="go" href={p.repo} target="_blank" rel="noopener noreferrer">View code →</a></div>}
      </div>
    </article>
  );
}

function Bar({ n, v }) {
  const r = useRef(null), f = useRef(null);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { f.current.style.width = v + "%"; io.disconnect(); } }, { threshold: 0.4 });
    io.observe(r.current); return () => io.disconnect();
  }, []);
  return <div className="bar" ref={r}><div className="l"><span>{n}</span><span>{v}%</span></div><div className="t"><div className="f" ref={f} /></div></div>;
}

function Nav({ dark, toggle, openCmd }) {
  const [active, setActive] = useState(""), [open, setOpen] = useState(false);
  const bar = useRef(null), ind = useRef(null), refs = useRef({});
  useEffect(() => {
    const on = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight || 1;
      bar.current.style.transform = `scaleX(${Math.min(1, window.scrollY / max)})`;
      let cur = ""; for (const [id] of NAV) { const s = document.getElementById(id); if (s && s.getBoundingClientRect().top < window.innerHeight * 0.4) cur = id; }
      setActive(cur);
    };
    on(); window.addEventListener("scroll", on, { passive: true }); return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => {
    const place = () => { const a = refs.current[active], i = ind.current; if (!a) { i.style.opacity = 0; return; } i.style.opacity = 1; i.style.width = a.offsetWidth - 28 + "px"; i.style.transform = `translateX(${a.offsetLeft + 14}px)`; };
    place(); window.addEventListener("resize", place); return () => window.removeEventListener("resize", place);
  }, [active]);
  const click = (id) => (e) => { e.preventDefault(); go(id); setOpen(false); };
  return (
    <header className="nav">
      <div className="wrap">
        <a className="logo" href="#top" onClick={click("top")} aria-label="Ravinder Singh, home">RS</a>
        <nav className="links" aria-label="Sections">
          <span className="ind" ref={ind} />
          {NAV.map(([id, l]) => <a key={id} ref={(n) => (refs.current[id] = n)} href={"#" + id} className={active === id ? "on" : ""} onClick={click(id)}>{l}</a>)}
        </nav>
        <div className="tools">
          <button className="kbtn" onClick={openCmd} aria-label="Open command palette">Search <kbd>{MOD} K</kbd></button>
          <button className="iconbtn" onClick={toggle} aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}>{dark ? "☀" : "☾"}</button>
          <button className="iconbtn burger" onClick={() => setOpen(!open)} aria-expanded={open} aria-label="Menu">{open ? "✕" : "☰"}</button>
        </div>
      </div>
      <div className={"mmenu glass" + (open ? " open" : "")}>
        {NAV.map(([id, l]) => <a key={id} href={"#" + id} onClick={click(id)}>{l}</a>)}
        <a href="#" onClick={(e) => { e.preventDefault(); setOpen(false); openCmd(); }}>Command palette</a>
      </div>
      <div className="prog" ref={bar} />
    </header>
  );
}

function Palette({ open, setOpen, cmds }) {
  const [q, setQ] = useState(""), [i, setI] = useState(0);
  const list = cmds.filter((c) => c.label.toLowerCase().includes(q.toLowerCase()));
  useEffect(() => { setI(0); }, [q]);
  useEffect(() => { if (open) setQ(""); }, [open]);
  if (!open) return null;
  const run = (c) => { setOpen(false); setTimeout(c.run, 50); };
  const key = (e) => {
    if (e.key === "Escape") setOpen(false);
    else if (e.key === "ArrowDown") { e.preventDefault(); setI((i + 1) % Math.max(1, list.length)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setI((i - 1 + list.length) % Math.max(1, list.length)); }
    else if (e.key === "Enter" && list[i]) run(list[i]);
  };
  return (
    <div className="pal-back" onMouseDown={() => setOpen(false)}>
      <div className="pal glass" role="dialog" aria-modal="true" aria-label="Command palette" onMouseDown={(e) => e.stopPropagation()}>
        <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={key} placeholder="Type a command… (jump to a section, switch theme, open links)" aria-label="Search commands" />
        <ul>
          {list.map((c, n) => <li key={c.label} className={n === i ? "sel" : ""} onMouseEnter={() => setI(n)} onClick={() => run(c)}>{c.label}<small>{c.hint}</small></li>)}
          {!list.length && <li>No matching command</li>}
        </ul>
      </div>
    </div>
  );
}

function ToTop() {
  const r = useRef(null);
  useEffect(() => {
    const on = () => { const max = document.documentElement.scrollHeight - window.innerHeight || 1; r.current.classList.toggle("show", window.scrollY > 600); r.current.style.setProperty("--pr", Math.min(100, window.scrollY / max * 100)); };
    on(); window.addEventListener("scroll", on, { passive: true }); return () => window.removeEventListener("scroll", on);
  }, []);
  return <button ref={r} className="totop" onClick={() => go("top")} aria-label="Back to top"><span>↑</span></button>;
}

function ContactForm() {
  const [v, setV] = useState({ name: "", email: "", message: "", company: "" }), [err, setErr] = useState({}), [st, setSt] = useState(""), [busy, setBusy] = useState(false);
  const t0 = useRef(Date.now());
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    if (v.company) { setSt("Thanks! Your message was sent."); return; } /* honeypot: bots fill the hidden field */
    const er = {};
    if (v.name.trim().length < 2) er.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) er.email = "Please enter a valid email address.";
    if (v.message.trim().length < 10) er.message = "Please write at least 10 characters.";
    if (v.message.length > 1000) er.message = "Keep it under 1000 characters.";
    setErr(er); if (Object.keys(er).length) return;
    if (Date.now() - t0.current < 3000) { setSt("That was quick! Please check your message and send again."); return; } /* timing check */
    setBusy(true);
    if (FORM_ENDPOINT) {
      try {
        const r = await fetch(FORM_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ name: v.name, email: v.email, message: v.message }) });
        setSt(r.ok ? "Thanks! Your message was sent." : "Something went wrong. Please email me directly."); if (r.ok) setV({ name: "", email: "", message: "", company: "" });
      } catch (x) { setSt("Could not send. Please email me directly."); }
    } else {
      window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent("Portfolio message from " + v.name)}&body=${encodeURIComponent(v.message + "\n\n— " + v.name + " (" + v.email + ")")}`;
      setSt("Your email app should open with the message ready to send.");
    }
    setBusy(false);
  };
  const F = ({ k, label, type = "text", area }) => {
    const Tag = area ? "textarea" : "input";
    return <div className="field"><label htmlFor={"f-" + k}>{label}</label><Tag id={"f-" + k} type={area ? undefined : type} value={v[k]} onChange={set(k)} aria-invalid={!!err[k]} aria-describedby={err[k] ? "e-" + k : undefined} maxLength={area ? 1200 : 120} />{err[k] && <div className="err" id={"e-" + k}>{err[k]}</div>}</div>;
  };
  return (
    <form className="form glass" onSubmit={submit} noValidate>
      <h3>Send a message</h3>
      {F({ k: "name", label: "Your name" })}
      {F({ k: "email", label: "Email", type: "email" })}
      {F({ k: "message", label: "Message", area: true })}
      <div className="hp" aria-hidden="true"><label>Company<input tabIndex={-1} autoComplete="off" value={v.company} onChange={set("company")} /></label></div>
      <button className="btn primary" type="submit" disabled={busy}>Send message</button>
      <div className="status" role="status" aria-live="polite">{st}</div>
    </form>
  );
}

function App() {
  const [filter, setFilter] = useState("All"), [theme, setTheme] = useState(null), [pal, setPal] = useState(false);
  const typed = useTyping(["Responsive websites", "React apps", "Python tools", "Things people enjoy using"]);
  const ist = useIST();
  useEffect(() => { if (theme) document.documentElement.setAttribute("data-theme", theme); }, [theme]);
  const dark = theme ? theme === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
  const toggle = () => setTheme(dark ? "light" : "dark");
  useEffect(() => {
    const k = (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPal((p) => !p); } };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, []);
  const open = (u) => () => window.open(u, "_blank", "noopener");
  const cmds = [
    ...NAV.map(([id, l]) => ({ label: "Go to " + l, hint: "Section", run: () => go(id) })),
    { label: "Toggle light / dark mode", hint: "Theme", run: toggle },
    { label: "Open GitHub", hint: "Link", run: open(LINKS.github) },
    { label: "Open LinkedIn", hint: "Link", run: open(LINKS.linkedin) },
    { label: "Send an email", hint: EMAIL, run: () => { window.location.href = LINKS.email; } },
    { label: "Copy email address", hint: "Clipboard", run: () => { try { navigator.clipboard.writeText(EMAIL); } catch (x) {} } },
    { label: "Scroll to top", hint: "Page", run: () => go("top") },
  ];
  const shown = PROJECTS.filter((p) => filter === "All" || p.type === filter);
  const loop = [...MARQUEE, ...MARQUEE];
  const Soc = () => (
    <div className="socials">
      <a className="soc glass" href={LINKS.github} target="_blank" rel="noopener noreferrer"><Icon d={GH} /> GitHub</a>
      <a className="soc glass" href={LINKS.linkedin} target="_blank" rel="noopener noreferrer"><Icon d={LI} /> LinkedIn</a>
      <a className="soc glass" href={LINKS.email}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d={MAIL} /></svg> {EMAIL}</a>
    </div>
  );
  return (
    <>
      <Loader /><Cursor /><Particles /><Mascot />
      <Nav dark={dark} toggle={toggle} openCmd={() => setPal(true)} />
      <Palette open={pal} setOpen={setPal} cmds={cmds} />
      <ToTop />
      <main id="top">
        <div className="hero">
          <span className="sticker" style={{ top: "14%", left: "54%" }} aria-hidden="true">✨</span>
          <span className="sticker" style={{ top: "66%", left: "47%", animationDelay: "-2s" }} aria-hidden="true">🚀</span>
          <span className="sticker" style={{ top: "8%", left: "6%", animationDelay: "-3s" }} aria-hidden="true">⚡</span>
          <div className="wrap"><div className="copy">
            <div className="hi">Hi, I’m Ravinder 👋</div>
            <h1>I build <span className="grad">{typed}</span><span className="caret" aria-hidden="true" /></h1>
            <p className="lead">Software developer from Ludhiana. I make web apps with React and tools with Python, and I’m finishing my MCA online.</p>
            <div className="btns">
              <a className="btn primary" href="#projects" onClick={(e) => { e.preventDefault(); go("projects"); }}>See my work</a>
              <a className="btn" href="#contact" onClick={(e) => { e.preventDefault(); go("contact"); }}>Contact me</a>
              <span className="hint">or press <kbd>{MOD} K</kbd></span>
            </div>
          </div></div>
        </div>

        <div className="marquee" aria-hidden="true"><div className="track">{loop.map((s, i) => <span key={i}>{s} <i>✦</i></span>)}</div></div>

        <section id="about"><div className="wrap about">
          <Reveal>
            <h2>A little about me</h2>
            <p>I completed my BCA at Gulzar Group of Institutes, Khanna in 2026 and I’m now pursuing a Master of Computer Applications online at Lovely Professional University.</p>
            <p>I learn by building. My projects range from a Python and SQLite student record system to React apps like an e-commerce store, a task dashboard and a live weather app. I care about clean, responsive interfaces that feel good to use.</p>
            <Soc />
          </Reveal>
          <Reveal className="facts" delay={120}>
            <div className="fact glass"><small>Availability</small><b><span className="live" />Open to full-time roles</b><span>Remote or on-site</span></div>
            <div className="fact glass"><small>Location & time zone</small><b>Ludhiana, India · IST (UTC+5:30)</b><span>Local time now: {ist}</span></div>
            <div className="fact glass"><small>Languages</small><b>English, Hindi, Punjabi</b></div>
            <div className="fact glass"><small>Education</small><b>MCA, 2026 – present</b><span>Lovely Professional University (online)</span></div>
          </Reveal>
        </div></section>

        <section id="projects" style={{ paddingTop: 0 }}><div className="wrap">
          <Reveal>
            <h2>Selected projects</h2>
            <p className="sub">Things I’ve designed and built. Hover a card to tilt it in 3D.</p>
            <div className="tabs" role="group" aria-label="Filter projects">
              {["All", "Web", "Python"].map((f) => <button key={f} className="tab" aria-pressed={filter === f} onClick={() => setFilter(f)}>{f}</button>)}
            </div>
          </Reveal>
          <Reveal><div className="cards">{shown.map((p) => <Tilt key={p.name} p={p} />)}</div></Reveal>
        </div></section>

        <section id="skills" style={{ paddingTop: 0 }}><div className="wrap">
          <Reveal>
            <h2>What I work with</h2>
            <p className="sub">Self-rated comfort levels, plus a playground. Tap a ball to launch it, or tap empty space to blast them all.</p>
          </Reveal>
          <Reveal className="skgrid">
            <div className="panel glass"><h3>Skill levels</h3>{BARS.map(([n, v]) => <Bar key={n} n={n} v={v} />)}<p className="note">Updated as I grow.</p></div>
            <div className="panel glass"><h3>Currently learning</h3><div className="learn">{LEARN.map(([i, t, d]) => <div className="lrn" key={t}><i>{i}</i><div><b>{t}</b><span>{d}</span></div></div>)}</div></div>
          </Reveal>
          <Reveal><Playground /></Reveal>
        </div></section>

        <section id="build" style={{ paddingTop: 0 }}><div className="wrap">
          <Reveal><h2>What I can build for you</h2><p className="sub">Work I can actually deliver today.</p></Reveal>
          <Reveal className="build">{BUILD.map(([i, t, d]) => <div className="bld glass" key={t}><i>{i}</i><h3>{t}</h3><p>{d}</p></div>)}</Reveal>
          <Reveal><h2>How I work</h2><p className="sub">A simple workflow, repeated for every project.</p></Reveal>
          <Reveal className="flow">{FLOW.map(([n, t, d]) => <div className="step glass" key={t}><em>{n}</em><h3>{t}</h3><p>{d}</p></div>)}</Reveal>
        </div></section>

        <section id="notes" style={{ paddingTop: 0 }}><div className="wrap">
          <Reveal><h2>Dev notes</h2><p className="sub">Short write-ups of things I’ve learned along the way.</p></Reveal>
          <Reveal className="notes">{NOTES.map(([t, b]) => <details className="nt glass" key={t}><summary>{t}</summary><p>{b}</p></details>)}</Reveal>
        </div></section>

        <section id="contact" style={{ paddingTop: 0 }}><div className="wrap">
          <Reveal className="contact">
            <div className="cta">
              <h2>Let’s build something together</h2>
              <p>I’m open to full-time roles, including remote. Email is the quickest way to reach me.</p>
              <a className="big" href={LINKS.email}>{EMAIL}</a>
              <div className="btns">
                <a className="btn" href={LINKS.linkedin} target="_blank" rel="noopener noreferrer"><Icon d={LI} /> LinkedIn</a>
                <a className="btn" href={LINKS.github} target="_blank" rel="noopener noreferrer"><Icon d={GH} /> GitHub</a>
              </div>
            </div>
            <ContactForm />
          </Reveal>
        </div></section>
      </main>
      <footer><div className="wrap"><span>© 2026 Ravinder Singh. Built with React.</span><span>Ludhiana, India · IST</span></div></footer>
    </>
  );
}

export default App;
